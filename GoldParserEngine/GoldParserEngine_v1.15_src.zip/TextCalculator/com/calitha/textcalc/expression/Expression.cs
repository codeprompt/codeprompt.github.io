using System;

namespace com.calitha.textcalc.expression
{

	public abstract class Expression
	{
		public abstract Value Evaluate();
	}
}
