using System;

namespace com.calitha.goldparser
{
	public interface IParser
	{
		void Parse(string source);
	}
}
